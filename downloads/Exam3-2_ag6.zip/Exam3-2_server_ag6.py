# pip install websocket-server
import threading
import socket
import json
from websocket_server import WebsocketServer
from controller import Supervisor
 
class SevenSegmentController:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor
        self.digit_segments = [
            ["seven_segment_a1", "seven_segment_b1", "seven_segment_c1", "seven_segment_d1", "seven_segment_e1", "seven_segment_f1", "seven_segment_g1"],
            ["seven_segment_a2", "seven_segment_b2", "seven_segment_c2", "seven_segment_d2", "seven_segment_e2", "seven_segment_f2", "seven_segment_g2"],
            ["seven_segment_a3", "seven_segment_b3", "seven_segment_c3", "seven_segment_d3", "seven_segment_e3", "seven_segment_f3", "seven_segment_g3"],
            ["seven_segment_a4", "seven_segment_b4", "seven_segment_c4", "seven_segment_d4", "seven_segment_e4", "seven_segment_f4", "seven_segment_g4"],
            ["seven_segment_a5", "seven_segment_b5", "seven_segment_c5", "seven_segment_d5", "seven_segment_e5", "seven_segment_f5", "seven_segment_g5"],
            ["seven_segment_a6", "seven_segment_b6", "seven_segment_c6", "seven_segment_d6", "seven_segment_e6", "seven_segment_f6", "seven_segment_g6"],
            ["seven_segment_a7", "seven_segment_b7", "seven_segment_c7", "seven_segment_d7", "seven_segment_e7", "seven_segment_f7", "seven_segment_g7"],
            ["seven_segment_a8", "seven_segment_b8", "seven_segment_c8", "seven_segment_d8", "seven_segment_e8", "seven_segment_f8", "seven_segment_g8"],
        ]
        self.segment_patterns = {
            0: [1,1,1,1,1,1,0],
            1: [0,1,1,0,0,0,0],
            2: [1,1,0,1,1,0,1],
            3: [1,1,1,1,0,0,1],
            4: [0,1,1,0,0,1,1],
            5: [1,0,1,1,0,1,1],
            6: [1,0,1,1,1,1,1],
            7: [1,1,1,0,0,0,0],
            8: [1,1,1,1,1,1,1],
            9: [1,1,1,1,0,1,1]
        }
        self.color_on = color_on
        self.color_off = color_off
        self.segment_nodes = []
        for digit in self.digit_segments:
            digit_fields = []
            for segment_def in digit:
                shape_node = self.supervisor.getFromDef(segment_def)
                if shape_node is None:
                    print(f"[ERROR] 找不到 DEF 名稱：{segment_def}")
                    continue
                try:
                    appearance_field = shape_node.getField("appearance")
                    appearance_node = appearance_field.getSFNode()
                    material_field = appearance_node.getField("material")
                    material_node = material_field.getSFNode()
                    diffuse_color_field = material_node.getField("diffuseColor")
                    digit_fields.append(diffuse_color_field)
                except Exception as e:
                    print(f"[ERROR] 處理 {segment_def} 時出錯: {e}")
            self.segment_nodes.append(digit_fields)
        print(f"[DEBUG] segment_nodes 結構: {[len(d) for d in self.segment_nodes]}")
 
        self.set_digit(2, 1)
 
    def set_digit(self, digit_index, value):
        pattern = self.segment_patterns[value]
        for i, state in enumerate(pattern):
            color = self.color_on if state else self.color_off
            try:
                self.segment_nodes[digit_index][i].setSFVec3f(color)
            except Exception as e:
                print(f"[ERROR] setSFVec3f 失敗: digit={digit_index}, seg={i}, error={e}")
 
    def display_number(self, number):
        if not (0 <= number <= 999):
            print("Error: Number out of range (0-999)")
            return
        hundreds = number // 100
        tens = (number % 100) // 10
        units = number % 10
        print(f"[DEBUG] 顯示數字: {number} (百:{hundreds} 十:{tens} 個:{units})")
        self.set_digit(1, tens)
        self.set_digit(0, units)
 
    def display_label_digits(self, digit_map):
        for digit_num, value in digit_map.items():
            seg_index = digit_num - 1
            if 0 <= seg_index < len(self.segment_nodes):
                self.set_digit(seg_index, value)
            else:
                print(f"[ERROR] 沒有這個顯示器: {digit_num}")
 
class WSSevenSegmentServer:
    def __init__(self, ipv4, port):
        self.up_sequence = [10, 25, 29, 32, 47]
        self.down_sequence = [10, 25, 29, 32, 47]
        self.current_number = 47
        self.supervisor = Supervisor()
        self.timestep = int(self.supervisor.getBasicTimeStep())
        self.controller = SevenSegmentController(self.supervisor, [0,1,0], [0,0,0])
        self.controller.display_number(self.current_number)
 
        label_map = {4:3, 5:2, 6:2, 7:1, 8:4}
        self.controller.display_label_digits(label_map)
 
        self.wss = WebsocketServer(host=ipv4, port=port)
        self.wss.set_fn_message_received(self.on_message)
 
    def on_message(self, client, server, message):
        print(f"[INFO] 原始收到訊息：{repr(message)}")
        try:
            data = json.loads(message)
            if isinstance(data, dict):
                msg = str(data.get('cmd', '')).strip().upper()
            else:
                msg = str(data).strip().upper()
        except Exception:
            msg = str(message).strip().upper()
        print(f"[INFO] 處理後訊息：{msg}")
        try:
            if msg == "W":
                if self.current_number in self.down_sequence:
                    idx = self.down_sequence.index(self.current_number)
                    next_idx = (idx + 1) % len(self.down_sequence)
                else:
                    next_idx = 0
                self.current_number = self.down_sequence[next_idx]
                self.controller.display_number(self.current_number)
                print(f"[INFO] W（下一個）切換到：{self.current_number}")
                server.send_message(client, f"W切換到: {self.current_number}")
            elif msg == "S":
                if self.current_number in self.up_sequence:
                    idx = self.up_sequence.index(self.current_number)
                    next_idx = (idx + 1) % len(self.up_sequence)
                else:
                    next_idx = 0
                self.current_number = self.up_sequence[next_idx]
                self.controller.display_number(self.current_number)
                print(f"[INFO] S（上一個）切換到：{self.current_number}")
                server.send_message(client, f"S切換到: {self.current_number}")
            else:
                print("[WARN] 收到未處理指令")
                server.send_message(client, f"未處理的訊息: {message}")
        except Exception as e:
            print(f"[ERROR] 處理訊息時發生錯誤: {e}")
            server.send_message(client, f"錯誤: {e}")
 
    def run_wss(self):
        print(f"[INFO] WebSocket server started on {self.wss.host}:{self.wss.port}, waiting for commands...")
        self.wss.run_forever()
 
    def run_supervisor(self):
        print("[INFO] Supervisor 迴圈啟動")
        while self.supervisor.step(self.timestep) != -1:
            pass
 
    def run(self):
        print("[INFO] 伺服器主程式已啟動")
        t1 = threading.Thread(target=self.run_wss, daemon=True)
        t2 = threading.Thread(target=self.run_supervisor, daemon=True)
        t1.start()
        t2.start()
        try:
            while True:
                pass
        except KeyboardInterrupt:
            print("[INFO] 結束伺服器...")
 
if __name__ == "__main__":
    ipv4 = "120.113.99.46"
    port = 8081
    WSSevenSegmentServer(ipv4, port).run()