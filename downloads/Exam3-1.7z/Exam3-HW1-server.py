import threading
import json
import socket
from websocket_server import WebsocketServer
from controller import Supervisor, Keyboard as WebotsKeyboard
import keyboard
import time

TIME_STEP = 32
MAX_VELOCITY = 10.0

robot = Supervisor()
webots_keyboard = WebotsKeyboard()
webots_keyboard.enable(TIME_STEP)
wheel1 = robot.getDevice("motor")
wheel1.setPosition(float('inf'))
wheel1.setVelocity(0)

def set_wheel_velocity(v1):
    wheel1.setVelocity(v1)

def reset_simulation():
    print("[反饋] Simulation: 重設 Webots 世界 (simulationReset) 並馬達停止")
    set_wheel_velocity(0)
    # simulationReset 會讓所有物件回到原始位置，controller也會重新啟動
    robot.simulationReset()

def pause_simulation():
    print("[反饋] Simulation: 暫停 Webots 世界 (simulationSetMode PAUSE) 並馬達停止")
    set_wheel_velocity(0)
    robot.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)

def resume_simulation():
    print("[反饋] Simulation: 恢復 Webots 世界 (simulationSetMode REAL_TIME)")
    robot.simulationSetMode(Supervisor.SIMULATION_MODE_REAL_TIME)

class IPv6WebsocketServer(WebsocketServer):
    def __init__(self, host, port):
        self.address_family = socket.AF_INET6
        super().__init__(host=host, port=port)

def on_message(client, server, message):
    print(f"收到新訊息: {message}")
    try:
        data = json.loads(message)
        direction = data.get("direction")
        if not direction:
            return
        if direction.lower() == "q":
            print("[反饋] WebSocket: 收到 q，馬達啟動")
            set_wheel_velocity(MAX_VELOCITY)
        elif direction.lower() == "r":
            print("[反饋] WebSocket: 收到 r，重設 simulation 並馬達停止")
            reset_simulation()
        elif direction.lower() == "esc":
            print("[反饋] WebSocket: 收到 ESC，暫停 simulation 並馬達停止")
            pause_simulation()
        elif direction.lower() in ("resume", "run"):
            print("[反饋] WebSocket: 收到 resume，恢復 simulation")
            resume_simulation()
    except json.JSONDecodeError:
        print("Invalid message received. Expected JSON format.")
    except Exception as e:
        print(f"Error handling message: {e}")

def start_websocket_server():
    server_ip = "2001:288:6004:17:fff1:cd25:0000:a033"
    server_port = 8081
    try:
        server = IPv6WebsocketServer(host=server_ip, port=server_port)
        server.set_fn_message_received(on_message)
        print(f"WebSocket server started on [{server_ip}]:{server_port}, waiting for commands...")
        server.run_forever()
    except Exception as e:
        print(f"Failed to start WebSocket server: {e}")

def start_arrow_key_control():
    print("terminal: 按 q 啟動馬達, r 重設, esc 暫停, e 恢復")
    while True:
        try:
            if keyboard.is_pressed("q"):
                print("[反饋] 本地鍵盤: q")
                set_wheel_velocity(MAX_VELOCITY)
                time.sleep(0.2)
            elif keyboard.is_pressed("r"):
                print("[反饋] 本地鍵盤: r -> 重設 simulation 並馬達停止")
                reset_simulation()
                time.sleep(0.5)
            elif keyboard.is_pressed("esc"):
                print("[反饋] 本地鍵盤: ESC -> 暫停 simulation 並馬達停止")
                pause_simulation()
                time.sleep(0.5)
            elif keyboard.is_pressed("e"):
                print("[反饋] 本地鍵盤: e -> 恢復 simulation")
                resume_simulation()
                time.sleep(0.5)
            time.sleep(0.05)
        except Exception as e:
            print(f"Error in arrow key control: {e}")
            break

def start_webots_simulation():
    try:
        while robot.step(TIME_STEP) != -1:
            key = webots_keyboard.getKey()
            if key == 27:  # ESC
                print("[反饋] Webots鍵盤: ESC -> 暫停 simulation 並馬達停止")
                pause_simulation()
            elif key in (ord('Q'), ord('q')):
                print("[反饋] Webots鍵盤: q（馬達啟動）")
                set_wheel_velocity(MAX_VELOCITY)
            elif key in (ord('R'), ord('r')):
                print("[反饋] Webots鍵盤: r -> 重設 simulation 並馬達停止")
                reset_simulation()
            elif key in (ord('E'), ord('e')):
                print("[反饋] Webots鍵盤: e -> 恢復 simulation")
                resume_simulation()
    except Exception as e:
        print(f"Simulation error: {e}")

if __name__ == "__main__":
    websocket_thread = threading.Thread(target=start_websocket_server, daemon=True)
    simulation_thread = threading.Thread(target=start_webots_simulation, daemon=True)
    arrow_key_thread = threading.Thread(target=start_arrow_key_control, daemon=True)

    websocket_thread.start()
    simulation_thread.start()
    arrow_key_thread.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down gracefully...")